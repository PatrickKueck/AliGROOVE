#!/usr/bin/perl
$|++;

#written by Bernhard Misof and Patrick Kueck, ZFMK, Bonn
#version of 07th October 2013

#updated by Bernhard Misof, 4th March 2008
#updated by Bernhard Misof, 7th March 2008
#updated by Bernhard Misof,11th March 2008
#updated by Bernhard Misof,26th March 2008
#updated by Bernhard Misof, 2nd April 2008
#updated by Bernhard Misof, 6th May   2008
#updated by Bernhard Misof,24th September  2008   => -e for nt sequences! -e for nt sequences disables N replacement for fuzzy ends of sequences!
#updated by Bernhard Misof,18th November   2008   => little bug if taxon names were mixed with pure numerics and alphanumerics
#updated by Sandra Meid,28th April 2011 => added autoflush ($| = 1)
#updated by Sandra Meid,28th April 2011 => changed SVG output, taxa names are now printed within svq space
#updated by Sandra Meid,22th June 2011  => ordered entries in TaxaList for svg drawing in alphabetical order
#updated by Sandra Meid,28th June 2011  => added Bio::Phylo and sub draw_tree_svg()
#updated by Sandra Meid,29th June 2011  => added sub tree_dist()
#updated by Patrick Kück,30the June 2011 => added sub write_tree_svg()
#updated by Patrick Kück,1st July 2011  => changed sub tree_dist() and write_tree_svg()
#updated by Patrick Kück,15st July 2011  => removed the the exclusion of identic taxon sequences a priori aligroove analyses
#updated by Patrick Kück,23rd July 2013  => changed output structure; enabled seq_sim NJ topologies if without best tree specification via -z option; source code redesign of line 1053-1819
#updated by Patrick Kück, 27th August 2013 => changed indentification of variable site positions line 598
#updated by Sandra Meid,29th August 2013  => changed output directory to same folder as input directory
#debugged by Patrick Kück, 27th August 2013 => changed taxon indentification of given topologies -> ')1.000000000:1.63' could not be recognized in line 154
#updated by Sandra Meid, 07th October 2013  => changed tree file output directory to same folder as input directory
# debugged by Patrick Kück, 22nd February 2017 => tree plotting corrected

use strict           ;
use warnings         ;
use AliGROOVE_module ;
use Tie::File        ;
use Fcntl            ;

use Bio::Phylo::IO "parse";
use Bio::Phylo::Treedrawer;
use File::Copy ;


#converts different line feeds in open process
use open IN => ":raw", OUT => ":raw" ;


##################################
# print $USAGE if infile or switches are missing
# declare and initialize variables
# process switches
# AliGROOVE_module::help is used to provide short describtions of options and their use
# AliGROOVE_module::get_options reads input given by @ARGV and changes default parameter if defined

our $transcript		= '-'	;
our $sequence_length	= '-'	;

our @variability		= ()	;
our $invariant		= 0		;
our @invar_sections		= ()	;
our @temp				= ()	;
our $n_sections		= 0		;
our @section			= ()	;

our @PAIRS_org			= ()	;
our @PAIRS				= ()	;
our %PAIRScores			= ()	;
our @Temp				= ()	;
our @Profile			= ()	;
our $position			= ()	;
our @Character_List		= ()	;
our $nchar				= '-'	;
our $ref_scoring		= ()	;
our $threshhold		= ()	;
our $random			= 20000000 ;
our $pairs				= $random ;


our (
	$file		,
	$window	,
	$option	,
	$indels	, 
	$phylotree	,
	$matrix
)	=  AliGROOVE_module::get_options () ;


=pod

=head2 Reading FASTA file

Fasta file is read and stored as a hash with taxon names as keys and references to sequence arrays as values. Sequences are stored as flat list, each position constituting an element. Only references to these hash elements are returned from the subroutine. The reference to the hash is used as a global variable indicated by our, only the file name is used as argument for the subroutine to open and read the file; will die if file has not bee found. Aliscore understands DNA ambiguity code, there is no need to replaces these. ALiGROOVE does not accept any sign except letters and indels in sequences. It will die if anything else is encountered in seqquences.

	command:
	our ($ref_FASTA)=Alignment_alpha::readFASTA_simple($file); 

number of taxa and taxon names are collected into an array for later comparison
ALiGROOVE attempts to estimate the data type, either nucleotide or amino acid data. ALiGROOVE considers sequences whith an ACTG content of > 0.8 (without counting indels and N) as nucleotide sequences, if less then 0.8 as amino acid data. It estimates data property from every sequence, if two sequences are considered of different data type, Aliscore stops. Aliscore might stop if a single nucleotide sequence contains more then 0.2 ambiguities. In almost every case, ALiGROOVE will correctly estimate data type, if it does not, it will stop and report on the problem. If the data contains sequences of more then 0.2 ambiguities, it might be advisable to recode ambiguities as N's or remove the particular sequence.
RNA sequences will be recoded to DNA sequences. Nucleotide data can be a mix of RNA/DNA data.

=cut
##################################



##################################
# FASTA READ IN
#reads file returns reference to FASTA Hash of file, taxon names are keys, sequence arrays are values, given in references
#if structures coded in dot/bracket format are present, these will separately be stored in hash
print 
<<FASTA;

	reading taxa from FASTA ...


FASTA

our ( $ref_FASTA, $ref_structures, $type ) = AliGROOVE_module::readFASTA_simple( $file );
#for my $msa_taxon ( keys %$ref_FASTA ){ print "\n" , $msa_taxon }

##############################################################################
# Check defined topology file for correct taxon names
# Store taxon names of tree file in @tree_taxa
my (
	$tree_line,
	$phylotree_uni,
	@tree_taxa,
);

if ( $phylotree ){
	
	#######################################
	# Read IN defined topology for tree tagging
	open  IN, "<".$phylotree || die "\n!FILE-ERROR!: Cannot open tree $phylotree!\n" ;
	chomp ($tree_line = <IN>); close IN;
	#######################################
	
	
	
	#######################################
	# The last closed counter bracket can be in front of the ourgroup:
	# e.g. ((T1:0.14356,T2:0.16546):1.2345)Outgroup;
	# This leads to problems using the AliGROOVE implemented split calculations
	# Therefore, the last closed counterbracket has to be placed behind the outgroup:
	# => ((T1:0.14356,T2:0.16546):1.2345,Outgroup);
	# This does not apply to branch length info:
	# => )0:0.12345;
	$tree_line =~ s/ //g ;
	
	if ( ( $tree_line =~ /\)\w+;$/ ) && ( $tree_line  !~ /\)(\d+)?(:)?\d+\.\d+;$/) ){ $tree_line  =~ s/\)(\w+);$/,$1\);/ }
	#######################################
	
	#print "\n", $tree_line, "\n" ; exit;
	
	#######################################
	# Extract taxon names of given topology as comma separated string $phylo
	$phylotree_uni = $tree_line ;
	$phylotree_uni =~ s/\)(\d?\.?\d+)?:\d+\.\w+(-\d+)?//g		; #)1.000000000:1.63 || )100:1.63E-5 || ):1.63E-5 || )100:1.63 || ):1.63 excluded !
	$phylotree_uni =~ s/:\d+\.\w+(-\d+)?//g				; # Terminal branch lengths excluded !
	$phylotree_uni =~ s/\)(:)?\d+(\.\d+)?;|\(+|\)+|;//g	; # ( || ); || ; || )0.0; || ):0.01; excluded !
	#######################################
	#print "\n", $phylotree_uni, "\n" ; exit;
	
	
	#######################################
	# Store taxon names of given topology in @tree_taxa
	# Check if taxon names in msa and tree are identic
	my (
		%seen_msa_taxa,
		%found_tre_taxa_in_msa,
	);
	
	for my $msa_taxon ( keys %$ref_FASTA ){ $seen_msa_taxa{$msa_taxon}++ }
	
	@tree_taxa = split "," , $phylotree_uni ;
	for my $tre_taxon ( @tree_taxa		){ unless ( $seen_msa_taxa{$tre_taxon}			){ die "\n\t!TREE-FILE-ERROR!:Cannot find Taxon ", $tre_taxon, " in alignment file "	, $file		, "!\n\tPlease mind capital letters!\n\n" } else{ $found_tre_taxa_in_msa{$tre_taxon}++} }
	for my $msa_taxon ( keys %$ref_FASTA	){ unless ( $found_tre_taxa_in_msa{$msa_taxon}	){ die "\n\t!TREE-FILE-ERROR!:Cannot find Taxon ", $msa_taxon, " in tree file "		, $phylotree	, "!\n\tPlease mind capital letters!\n\n" } }
	#######################################
}
##############################################################################


$type eq 'nt' and print
<<TYPE;


	data type       : nucleotide sequences
TYPE

$type eq 'aa' and print
<<TYPE;


	data type       : amino acid sequences
TYPE
;

$type eq 'nt' and print
<<REPORT;

	input ...
	
	infile		: $file
	window size	: $window
	indels		: $indels
	tree file	: $phylotree

REPORT


$type eq 'aa' and print
<<REPORT;

	input ...
	
	infile		: $file
	window size	: $window
	indels		: ambiguous
	tree file	: $phylotree
	matrix          : $matrix

REPORT


our @TAXA  = keys %$ref_FASTA;
our $NTaxa = keys %$ref_FASTA;

print 
<<TAXA;
	number of taxa  : $NTaxa

TAXA
;

our @STRUCTURES  = keys %$ref_structures;
our $NSTRUCTURES = keys %$ref_structures;
##################################



##################################
# checking and executing indel switch 
# if $type eq 'nt'...
# ...substitute T for U and reads sequence lengths
# ...report on recoding of RNA sequences
$type eq 'nt' and do {
	
	if ($option eq "N"){map {grep s/\-/N/,@$_} values %$ref_FASTA}
	
	$transcript  = map { grep  s/U/T/,@$_ } values %$ref_FASTA ;
	
	CHECK: { $sequence_length = @$_ and last CHECK for values %$ref_FASTA }
	
	print "\t","transcribed from RNA -> DNA","\n\n" if $transcript > 0 ;
};

# if $type eq 'aa'...
# ...replace indels for X in amino acid sequences
# ...read sequence lengths
$type eq 'aa' and do { 
	
	#map {grep s/\-/X/,@$_} values %$ref_FASTA;
	CHECK: { $sequence_length = @$_ and last CHECK for values %$ref_FASTA }
};
##################################



##################################
# get scoring matrix depending on sequence type
$ref_scoring = AliGROOVE_module::get_scoring ( $type, $matrix );

#for ( keys %$ref_scoring ) { print $_,"\t",$ref_scoring->{$_},"\n"};#exit;

=pod

=head2 Reading data type and scoring matrix

Reads data type and generates accordingly scoring matrix. In case of nucleotide data, the scoring matrix is a simple match mismatch scoring matrix, in case of ambiguous characters the mismatch is optimistically interpreted. If indels are considered 5th charaters, they are scored in a mismatch/match pattern. A BLOSUM62 is used for the amino acid scoring with indels and X scoring 0. For aminoacid scoring, a Monte Carlo approach is used to generate a threshhold value, given the actual window size and aminoacid composition of the data. 

=cut
##################################



##################################
# create cutoff value for aminoacid scoring using a delete half bootstrap plus MC resampling of scoring values, depending on window size

$type eq 'aa' and do {
	
print <<THRESHHOLD;
	generate threshhold value for amino acid data
	using $matrix
	
THRESHHOLD
	
	
	$threshhold = AliGROOVE_module::get_threshhold ( $ref_scoring, $window, $ref_FASTA ); 
	
	for ( keys %$ref_scoring ) {
		
		$$ref_scoring{$_} =  sprintf ("%.3f", $threshhold / $window ) - 0.01    if /\-\-/ ;
		
		if ( $matrix eq 'MATCH' ) { $$ref_scoring{$_} = -1 if /\-\-/ }
	}
};
##################################



#################################################################### START VARIABILITY
# Check variability of nt data
# reports on...
# ...invariant sections >$window
# ...scores site patterns
# ...records invariant sections
# ...variant sections to score
print <<START;
 	
	score site patterns ...

START

=pod

=head2 Checking variability

Checks for invariant sections across the alignment with an extension of >w+2 (w window size). Reports these sections and places information as an argument into subroutine later. This step improves speed, because only variable sections are actually scored for random similarity. A simple iteration through all sequence arrays is used to check variability of sites. A @temp array is used to create the list of variable sections, results are reported to terminal	

=cut

$type eq 'nt' and do {
	
	##################################
	# Check variability of nt data
	VARIABILITY:
	for my $i (0..$sequence_length-1){
		
		my %Patterns;
		
		for (values %$ref_FASTA){ $Patterns{$_->[$i]}++ };
		
		my $variability = keys %Patterns;
		
		if		(1 == $variability && 0 == grep /N|\-/,keys %Patterns){ push @section, $i }
		elsif	( ($window*2-2) <= @section ){
			
			push @invar_sections, (join",",@section);
			
			splice @section,$#section-($window-2);#print "@section\n";exit;
			
			push @temp, @section;
			
			$n_sections++
		}
		
		@section = ();
		
		$invariant++ if 1 == $variability && 0 == grep /N|\-/,keys %Patterns;
	}
	#print "@temp\n";exit;
	##################################
	
	
	
	##################################
	# report on variability
print <<INVAR;

	invariant positions: $invariant
INVAR
	
	{
		my $extend  = $window*2-2;
		
		$n_sections > 0 and do {
			
print <<SECTIONS;
	number of continuous invariant sections with size > $extend: $n_sections

SECTIONS
		};
		
		$n_sections == 0 and do {
			
print <<SECTIONS;
	no continuous section of size > $extend

SECTIONS
		};
	}
	##################################
	
	
	
	##################################
	# create array of variable sections	
	for my $position ( 0..$sequence_length-1 ){ push @variability, $position if 0 == grep/^$position$/,@temp };
	##################################
	
	
	
	##################################
	# remove positions > $sequence_length-($window-1)
	pop @variability until ( $variability[$#variability] <= $sequence_length-($window) );
	##################################
};
#################################################################### END VARIABILITY



#################################################################### START MC PROCESS
# execute MC process

$type eq 'nt' and do {
	
print <<MC

	starting MC process with sliding window and 100 resamplings each ...


MC
};

=pod

=head2 Scoring of randomly selected sequence pairs

The code starts the random selection process. It first generates al possible pairs from the list of taxon names and stops when all possible pairs are included. 

=cut


RANDOM:

##################################
# Calculate number of pairwise sequence comparisons
my $max_PAIRS	= ($NTaxa)*($NTaxa-1)/2;
##################################



##################################
# Remove empty @TAXA elements
# Count N taxa
# Die if N taxa <= 1
my $TAXA		= join",",@TAXA;

for ($TAXA){
	
	s/^\,+//x   ;
	s/\,+/\,/xg ;
	s/\,+$//x   ;
}

@TAXA 			= split",",$TAXA;

die "\n\tnot enough taxa!\n\n" if 1 >= @TAXA ;  
##################################



##################################
# generate set of all possible pairs
until (1 == @TAXA){
	
	my $first = shift @TAXA ;
	
	push @PAIRS_org, ($first.",".$TAXA[$_]) for(0..$#TAXA) ;
}

my $number = @PAIRS_org ;
##################################



##################################
# report on number of pairs and random switch
print <<MAX;

	$max_PAIRS pairs are scored!
	
MAX
##################################



##################################
# if variable random exceeds max number of pairs, all pairs are evaluated
@PAIRS=@PAIRS_org ;
##################################



##################################
# start scoring of sequence pairs using parsimony scoring subroutine
=pod

=head3 Scoring

For each entry in the pairs list, it uses the two taxon names to look in the data hash for both sequences and uses the subroutine C>> nuc/aa_score_two >> with the scoring type, flat list of variable characters and both sequence references as arguments. All arguments are provided as references. The scoring profile is returned as a reference. Description of the scoring process see Alignment_alpha.pm. The list of arguments must be in order, reference to the scoring type must be first.

=cut

my $counter = 1;

for (@PAIRS){
	
	my ($taxon1,$taxon2) = split "\," ;
	
	##################################
	# report pairwise comparisons
	printf "\tpair: %-6.6s \-\>\ttaxon1: %-10.10s\ttaxon2: %-10.10s\n" , $counter, $taxon1, $taxon2 ;
	##################################
	
	
	
	##################################
	#subroutine nuc/aa_score_two delivers a reference to the scoring array for the two sequences, it expects as input four arguments, first an option, window size, and two sequences as 1-dimensional arrays
	my $score;
	$score = AliGROOVE_module::nuc_score_two	($ref_scoring, \@variability,	$window,$$ref_FASTA{$taxon1},$$ref_FASTA{$taxon2})	if $type eq 'nt';#print "@$score\n";exit;
	$score = AliGROOVE_module::aa_score_two	($ref_scoring, $threshhold,	$window,$$ref_FASTA{$taxon1},$$ref_FASTA{$taxon2})	if $type eq 'aa';#print "@$score\n";exit;
	##################################
	
	
	
	##################################
	#count the frequency of minus scores in score array and reports
	my $count = grep /\-\d/,@$score ;
	
	print "\t            \tpositions below base line: ",$count,"\n";
	##################################
	
	
	
	##################################
	# transfer the score as a string into score collector array
	# %PAIRScores: key->Taxon1;;Taxon2; value->commata separated similarity scores of each seq position (ranging from -6 to +6)
	my $key			= $taxon1.";;".$taxon2 ;
	$PAIRScores{$key}	= (join"\,",@$score) ;
	##################################
	
	$counter++
}
##################################

#for ( keys %PAIRScores ){ print $_,"\n",$PAIRScores{$_},"\n";exit}

=pod

=head3 Single Profiles

Single profiles have been collected in hash with keys taxon1;;taxon2 and value profile as string, values separated by commatas!

=cut

#################################################################### END MC PROCESS



##################################
# Store variabel positions in @variable_positions
# %$ref_FASTA -> keys: Sequencename; value -> array of single sequence character states (in order of sequence increasing positions)
my @variable_positions = () ;

VARIABILITY:
for my $i (0..$sequence_length-1){
	
	my %Patterns;
	
	for (values %$ref_FASTA){ $Patterns{$_->[$i]}++ };
	
	my $counter = 0 ;
	
	#for ( keys %Patterns ){ $counter++ if ( ($Patterns{$_} > 1) and ($_ ne "N|X") ) } CHANGED IDENTIFICATION oF VARIABLE SITE POSITIONS
	for ( keys %Patterns ){ $counter++ if ( $Patterns{$_} < $NTaxa ) }
	
	push @variable_positions , $i if $counter > 1
}

#print "\n\n\n@variable_positions\n";exit;
##################################



##################################
# Calculate sum of single profiles
# %PAIRScores: key: taxon1;;taxon2 ; value -> similarity distance score
=pod

=head3 Calculates Sum of single Profiles

Single profiles are summed up for each pair excluding parsimony uninformative positions

=cut


for my $pair ( keys %PAIRScores ){
	
	my	@set = split "," , $PAIRScores{$pair} ;
		@set = @set[@variable_positions] ;
	
	$PAIRScores{$pair}  = 0 ;
	for ( @set ){ $PAIRScores{$pair} += ($_/6) } 
	$PAIRScores{$pair} /= @variable_positions ;
}
##################################



##################################
# Remove empty @TAXA elements
# order entries in alphabetical order
@TAXA	= keys %$ref_FASTA ;
$TAXA	= join",",@TAXA;

for ($TAXA){
	
	s/^\,+//x   ;
	s/\,+/\,/xg ;
	s/\,+$//x   ;
}

@TAXA			= split ",", $TAXA ;
@TAXA			= sort	(@TAXA)	;
my @PAIR_TAXA	= @TAXA ;

#for (@PAIR_TAXA){print $_,"\n"} exit;
##################################



#################################################################### START GENERATION OF ALIGROOVE SIM DIST MATRIX
# Generate AliGROOVE similarity matrix
=pod

=head3 Writing PAIR score matrix


=cut

#print $_,"\t",$PAIRScores{$_},"\n" for keys %PAIRScores ;exit;


my @groove_matrix = () ;

##################################
# push @groove_matrix first row -> taxon row
# @PAIR_TAXA includes all taxa, alphabetically ordered
push @groove_matrix , [ 'taxa', @PAIR_TAXA ] ;
##################################



##################################
# push @groove_matrix next rows with pairwise similarity distances of a single taxon to all other taxa
my $taxa_counter = 0 ;

until (0 == @TAXA){
	
	my @set = () ;
	
	##################################
	# draw taxon for this matrix row
	my $first = shift @TAXA ;
	##################################
	
	
	
	##################################
	# push @set first row element -> taxon
	# push 10 for pairwise distances which are already printed between taxon combinations (triangle distance matrix)
	# or between identic taxa
	$taxa_counter++ ;
	
	push @set,	$first ; 
	push @set,	10 for ( 1..$taxa_counter ); 
	##################################
	
	
	
	##################################
	# push remaining distance similarity scores
	# entries in scores hash are not redundant => $first.";;".$TAXA[$_] || $TAXA[$_].";;".$first
	push @set,	($PAIRScores{$first.";;".$TAXA[$_]} || $PAIRScores{$TAXA[$_].";;".$first}) for(0..$#TAXA) ;
	##################################
	
	
	##################################
	# each line in @groove_matrix as single array
	# each element of each line -> single array element
	push @groove_matrix, \@set
	##################################
}
##################################



##################################
# new list containing strings
# each mazrix line in @groove_list numbered array
# each numbered array contains all line elements as string variabel
my @groove_list;
my $it = 0;

for my $entryIt (@groove_matrix){
	
	my $matrixstring	= join " ", @$entryIt ;
	$groove_list[$it]	= $matrixstring;
	
	$it++;
}
#for (@groove_list){print $_, "\n"} exit;
##################################



##################################
# print AliGROOVE similarity distance matrix as svg
=pod

=head3 Drawing PAIR score matrix in svg


=cut

write_matrix_svg ( $file , \@groove_matrix ) ;


undef (%$ref_FASTA);

my ($user,$system,$cuser,$csystem) = times;

print <<TIME;

	time used: $user sec

TIME
##################################



###############################################################################################################
##########################################################################
	
	##################################
	# Generate AliGROOVE result files of...
	# ...AliGROOVE seq_sim matrix as .txt file -> OUTinfo_mat
	(	my	$filename = $file )		=~ s/^.*\/// ;
			$filename			=~ s/.fas$|.fasta$// ;
	(	my 	$filepath = $file)		=~ s/$filename// ;
			$filepath			=~ s/.fas$|.fasta$// ;
	
	my		$ss_matrix_txt = $filepath."AliGROOVE_seqsim_matrix_".$filename.".txt" ;
	open OUTinfo_mat, ">".$ss_matrix_txt || die "\n\t!FILE-ERROR!:Cannot open ", $ss_matrix_txt, "\n" ;
	##################################
	
	
	
	##################################
	# Define global variabels
	my (	%column_number_of_taxon,				# key: taxon; value: column number in aligroove seqsim matrix
			%line_number_of_taxon,					# key: taxon; value: line number in aligroove seqsim matrix
			@matrix_value,							# list of list -> key1: line number key2: column number
			$outputstring_matrix_scores,			# outputstring of AliGROOVE seq_sim distance matrix
	) ;
	##################################
	
	
	
	##################################
	# print first distance matrix row
	# asign taxon associated column number
	my @taxonline = split " ", $groove_list[0] ;
	for ( 1 .. @taxonline-1   ){ 
		
		print OUTinfo_mat "\t", $taxonline[$_] ;
		$column_number_of_taxon{$taxonline[$_]} = $_
	}
	print OUTinfo_mat "\n" ;
	##################################
	
	
	
	##################################
	# Assign single AliGROOVE seq_sim values to...
	# ...@matrix_value, $outputstring_matrix_scores, %line_number_of_taxon
	for my $linenumber ( 1 .. @groove_list-1 ){ 
		
		##################################
		# Store single column values of AliGROOVE seq_sim matrix of single line in @line_parts
		# assign line associated taxon as first column value in @matrix_value
		# assign taxon associtaed line number to %line_number_of_taxon
		# assign taxon of given line to outputstring $outputstring_matrix_scores
		my @line_parts								= split " ", $groove_list[$linenumber] ;
		$matrix_value[$linenumber][0]			= $line_parts[0] ;
		$line_number_of_taxon{ $line_parts[0] }	= $linenumber    ; 
		
		$outputstring_matrix_scores				= $outputstring_matrix_scores.$line_parts[0] ;
		##################################
		
		
		
		##################################
		# Assign single AliGROOVE seq_sim values of @line_parts to @matrix_value -> $matrix_value[linenumber][columnnumber] = seq_sim_value
		# Assign single AliGROOVE seq_sim values of @line_parts to outputstring $outputstring_matrix_scores
		for my $column_number ( 1 .. @line_parts-1 ){ 
			
			################################## ASSIGN AliGROOVE SEQ SIM DIST MATRIX
			# Assignment of AliGROOVE identified seq_sim scores
			$matrix_value[$linenumber][$column_number] = $line_parts[$column_number] ;
			$outputstring_matrix_scores = $outputstring_matrix_scores."\t".$line_parts[$column_number] ;
			##################################
		}
		
		$outputstring_matrix_scores = $outputstring_matrix_scores."\n" ;
		##################################
	}
	##################################
	
	
	
	##################################
	# Print AliGROOVE seq_sim matrix as .txt file
	print OUTinfo_mat $outputstring_matrix_scores ;
	close OUTinfo_mat ; 
	##################################
	
	
	
	#######################################
	# TREE TAGGING if topology for tree tagging has been defined
	if ($phylotree) {
		
		#######################################
		# Generate AliGROOVE result files of...
		# ...Tree tagging info as .txt file -> OUTinfo_ali
		# ...Tagged tree as .svg file -> 
		(	my	$tagged_tree_name = $phylotree ) 	=~ s/^.*\/// ;
				$tagged_tree_name			=~ s/.tre$|.txt$|.tree$// ;

		(	my $treefilepath = $phylotree )		=~ s/$tagged_tree_name// ;
				$treefilepath			=~ s/.tre$|.txt$|.tree$//  ;
				
			
			my	$tagging_inf_name = $treefilepath."AliGROOVE_tagged_info_".$tagged_tree_name.".txt" ;
			$tagged_tree_name = $treefilepath."AliGROOVE_tagged_tree_".$tagged_tree_name.".svg" ;
		
		open  OUTinfo_ali, ">".$tagging_inf_name || die "\n\t!FILE-ERROR!:Cannot open ", $tagging_inf_name, "\n" ;
		print OUTinfo_ali  "AliGROOVE tagging information\n\nOriginal Topology: ", $phylotree ,"\n", $tree_line, "\n\nFound Taxa in Topology:\n", $phylotree_uni ;
		#######################################
		
		
		
		#######################################
		# Define global variabel
		my (
			%dist_hash ,				# =	tree_dist		( $phylotree, $filename, @groove_list );
			%splitvalue_of_substring,	# key: 
		) ;
		#######################################
		
		
		
		##############################################################################
		# SPLITCALCULATIONS of TERMINAL BRANCHES
		# Calculate split values of terminal branches -> &calculate_split_distance
		# Store single split values of terminal branches in... 
		# ...%splitvalue_of_substring
		# ...%dist_hash
		# Print Splitnumber, Sequence Similarity Distance and terminal branch associated taxa in AliGROOVE tagging info .txt file
		print OUTinfo_ali "\n\nTerminal Branches:\nSplitnumber\tSequence Similarity Distance\tTerminal Branch Associated Taxon\n" ;
		
		my $counter_split	= 0 ;
		
		for my $single_taxon ( @tree_taxa ){
			
			$counter_split++;
			
			$splitvalue_of_substring{$single_taxon} = &calculate_split_distance ( $single_taxon , \@matrix_value, \%column_number_of_taxon, \%line_number_of_taxon, \@tree_taxa ) ;
			
			print OUTinfo_ali $counter_split, "\t", $splitvalue_of_substring{$single_taxon}, "\t=>\t", $single_taxon, "\n";
		}
		##############################################################################
		
		
		
		##############################################################################
		# SPLITCALCULATIONS of INTERNAL BRANCHES -> &calculate_split_distance
		my @pairs ;
		my $counter_pos		= 0 ; 
		my $counter_bracket	= 0 ;
		
		print OUTinfo_ali "\nInternal Branches\nSplitnumber\tSequence Similarity Distance\tTerminal Branch Associated Taxa\n" ;
		
		#######################################
		# store each newick sign in @tree_signs
		my @tree_signs = split "", $tree_line ; # $tree_line -> original newick tree !
		#######################################
		
		
		
		#######################################
		# Identify paired bracket positions by counting each position $counter_pos++
		# Open bracket positions stored in @pairs
		for my $sign ( @tree_signs ){
			
			#######################################
			# Open bracket positions stored in @pairs
			if		( $sign =~ /\(/ ){ push @pairs, $counter_pos }
			#######################################
			
			
			
			#######################################
			# For each closed bracket identify associated substring and calculate split support
			# for associated internal branch
			elsif	( $sign =~ /\)/ ){
				
				#######################################
				# Identify substring length
				my $dist_com ;
				my $pos_1			= pop  @pairs ;
				my $pair_length	= $counter_pos - $pos_1 ;
				#######################################
				
				
				
				#######################################
				# unless first bracket pair (including the complete newicck string)...
				# ...identify taxa of newick substring ($substring)
				# ...sort taxa of newick substring sort(@taxa_of_substring)
				# ...calculate splitvalues of internal branch associated with substring taxa (&calculate_split_distance_1 or &calculate_split_distance_2)
				# ...store 
				unless ( $pos_1 == 0 ){
					
					# extract substring taxa comma separated
					my	$substring =  substr ( $tree_line, $pos_1, $pair_length+1 ) ;
						$substring =~ s/\)(\d?\.?\d+)?:\d+\.\w+(-\d+)?//g                 ; # )100:1.63E-5 || ):1.63E-5 || )100:1.63 || ):1.63 removed ! ## neu, da sonst auch evtl. zahlen am ende von taxonnamen weg
						$substring =~ s/:\d+\.\w+(-\d+)?//g                         ; # Exclude terminal branch lengths
						$substring =~ s/\)(:)?\d+(\.\d+)?;$|\(|\);|;//g             ; # ( || ); || ; removed !
						$substring =~ s/\)+/,/g                                     ; # ) || )))) substituted to ',' because some rooted trees like bioperl print rooted taxon in newick trees without commata like '....)OUTGROUPTAXON;'
						$substring =~ s/,+/,/g                                      ; # , || ,,,, to ',' because taxa will be splitted later by commata
					##
					
					# sort substring taxa alphabetically
					my @taxa_of_substring	=  split  ",", $substring ; 
					$substring				=  join  (",", sort(@taxa_of_substring)); 
					##
					
					# count substring
					$counter_split++ ;
					##
					
					# calculate split value of associated internal branch
					$splitvalue_of_substring{$substring} = &calculate_split_distance ( $substring , \@matrix_value, \%column_number_of_taxon, \%line_number_of_taxon, \@tree_taxa ) ;
					##
					
					# print tagging info
					print OUTinfo_ali $counter_split, "\t", $splitvalue_of_substring{$substring}, "\t=>\t", $substring, "\n"
					##
				}
				#######################################
			}
			#######################################
			
			#######################################
			## Count newick string position +1
			$counter_pos++
			#######################################
		}
		#######################################
		
		#return %dist_hash;
		##############################################################################
		
		
		write_tree_svg	( $phylotree, $tagged_tree_name );
		read_tree_svg	( \$tagged_tree_name, \$groove_list[0], \%splitvalue_of_substring );
	}
	
	
	
	
############################################################################
###############################################################################################################






exit 0;	

#finish

###############################################################################################################
############################################################################





sub calculate_split_distance {
	
	my $tree_sub_string	= $_[0] ; # branch associated taxon substring
	my $aref_dist_matrix	= $_[1] ; # list of list -> key1: line number key2: column number
	my $href_tax_col		= $_[2] ; # key: taxon; value: column number in aligroove seqsim matrix
	my $href_tax_line		= $_[3] ; # key: taxon; value: line number in aligroove seqsim matrix
	my $aref_taxa_all		= $_[4] ; # array, including all tree taxa
	
	
	
	#######################################
	# Store given taxa in @taxa and %seen
	my @taxa = split ",", $tree_sub_string ;
	my %seen;  for (@taxa){ $seen{$_}++ }
	#######################################
	
	
	
	#######################################
	# Calculate split distance value OF EACH SUBSTRING TAXON AND EACH TAXON WHICH IS NOT!! PART OF THE SUBSTRING $tree_sub_string by...
	# ...summarizing single seq_sim values between each taxon pair in stringvariabel $dist_value_common
	# Count number of taxon comparings by $counter_comparings
	# Calculate mean distance value by deviding total seq_sim distance score through number of taxon comparisons:
	# $dist_value_common = $dist_value_common / $counter_comparings
	# return final split distance score observed from single seq_sim scores
	my $counter_comparings = 0 ;
	my $dist_value_common  = 0 ;
	for my $taxon_in (@taxa){
		
		for my $taxon ( sort @$aref_taxa_all ){ unless ( $seen{$taxon} ){
				
				if ( $href_tax_line->{$taxon} ){
					
					my @group = sort ( $taxon_in, $taxon ) ;
					$dist_value_common += $aref_dist_matrix->[$href_tax_line->{$group[0]}][$href_tax_col->{$group[1]}] ;
					$counter_comparings++
				}
				else{ die "\n!TreeError!: $taxon not included in AliGROOVE fasta infile\n" }
			}
		}
	}
	
	( $counter_comparings > 0 ) ? ( $dist_value_common = $dist_value_common / $counter_comparings ) : ( $dist_value_common = 0 ) ;
	return $dist_value_common;
	#######################################
}


sub write_tree_svg {

	my ( $topology , $outfile ) = @_ ;
	my   $string;

	open    TREEIN, "<".$topology or die $!;
	while (<TREEIN>){ $string .= $_ }
	close   TREEIN                          ;

	my $tree = parse( -format => "newick", -string => $string )->first;

	my $treedrawer = Bio::Phylo::Treedrawer->new(
		-width  => 800     ,
		-height => 600     ,
		-shape  => "rect"  , # curvogram
		-mode   => "phylo" , # cladogram
		-format => "Svg"   ,
	);

	$treedrawer->set_branch_width(2);

	$treedrawer->set_scale_options(
		-width => "100%" ,
		-major => "100%" , # major cross hatch interval
		-minor => "100%" , # minor cross hatch interval
	);

	$treedrawer->set_tree($tree);

	open  TREEOUT, ">".$outfile;
	print TREEOUT $treedrawer->draw;
	close TREEOUT;
}


sub read_tree_svg {
	
	my $sref_svg_tree				= $_[0] ;
	my $sref_1st_matrix_line		= $_[1] ;
	my $href_value_of_substring	= $_[2] ;
	
	
	
	###############################
	# READ IN SVG TOPOLOGY
	open  IN, "<".$$sref_svg_tree or die "\n!FILE-ERROR!: Can not open ", $$sref_svg_tree, "!\n" ;
	chomp ( my @svg_lines = <IN> ); close IN;
	###############################
	
	
	
	my	$svg_inputstring	= join "\n", @svg_lines ; #if ($svg_inputstring=~/\n    <text class=/ ){ print $svg_inputstring, "\n" } exit;
		$svg_inputstring	=~ s/\n\s+<text class=/ <text class=/g ; 
		$svg_inputstring	=~ s/<\/text>/\n<\/text>/g ; 
		@svg_lines			= split "\n", $svg_inputstring ;
	
	
	
	###############################
	# Associate each matrix taxon to hash %seen; key: taxon; value: 1
	my @matrix_taxa = split " ", $$sref_1st_matrix_line ;
	my %seen; for my $matrix_taxon ( 1 .. @matrix_taxa-1 ){ $seen{$matrix_taxa[$matrix_taxon]}++ }
	###############################
	
	
	my ( %polyline_of_taxa, %startpoint_of_taxa ) ;
	for my $line ( @svg_lines ){ #print "k ", $line;
		
		if ( $line =~ /polyline points=/ ){ #print "\n", $line, "\n";
			
			######################################################################
			### Extrahierung der Astkoordinaten
			
			###################################
			# Entfernen der zeichen vor und nach den svg koordinaten
			#( my $line_coordinates = $line ) =~ s/"//g ; print "\n1: ", $line_coordinates;
			#     $line_coordinates           =~ s/ style=stroke: black; stroke-width: 2\s+\/> <text class=taxon_text\w+$//g ; print "\n2: ", $line_coordinates; print "\n";exit;
			###################################
		
			###################################
			# 0. Element: Branch_start 2.Element: Branch_ende
			my	@coo_element	= split "\"",	$line ; #for (@coo_element){print "\nel: ", $_}
			my	@coordinates	= split " ",	$coo_element[1] ; #for (@coordinates){print "\nco: ", $_}
				@coo_element	= () ;
			###################################
			
			
			
			if ( $line =~ /<text class="taxon_text"/ ){ #print "\ntext", $line, "\n";
				
				###################################
				# Aufbrehcne der Zeile an '>'-stellen
				# Anpassen der svg_taxonnamen an matrix-taxa (leerzeichen zu underline umwandeln)
				# Zurodnung der startkoordinate (1. Wert)
				my @parts						=  split '>', $line ;
				$parts[2]						=~ s/ /_/g ;
				$polyline_of_taxa{$parts[2]}	=  $line ; #print "taxon", $parts[2], "\n\n";
				push @{$startpoint_of_taxa{$coordinates[0]}}, $parts[2] ;
				###################################
			}
			
			
			else{ #print "\nnon-text", $line, "\n";
				
				###################################
				# Zurodnung der endkoordinate (3. Wert)
				# zu taxa deren 1.wert mit dieser kordinate beginnt
				# Taxa in @taxa_of_line sammeln, sortieren
				# und als hashkey speichern; value: die ganze zeile
				my	@taxa_of_line			= exists($startpoint_of_taxa{$coordinates[2]}) ? @{$startpoint_of_taxa{$coordinates[2]}} :( ) ;
					@taxa_of_line			= sort   @taxa_of_line ; 
				my	$taxa					= join  (",", sort(@taxa_of_line)); 
				$polyline_of_taxa{$taxa}	= $line ;
				
				push @{$startpoint_of_taxa{$coordinates[0]}}, @taxa_of_line ; #print "@taxa_of_line=>$coordinates[0]\n\n" ;
				###################################
			}
		}
	}
	
	#for my $taxa_lines_svg ( sort keys %polyline_of_taxa ){ print "\n$taxa_lines_svg:\t$polyline_of_taxa{$taxa_lines_svg}\n" }
	
		
	###############################
	# Wenn Substring mit similarity score im svg file wiedergefunden wird,
	# die astfarbe in der dazugehörigen svg zeile dem berechneten similarity score zuordnen
	CLADE:
	for my $taxon_clade (keys %$href_value_of_substring){#print "\ntaxon clade:\t", $taxon_clade;
			
		for my $svg_line (@svg_lines){ #print "\nsvg line:\t", $svg_line;
			
			if  ( $svg_line eq $polyline_of_taxa{$taxon_clade} ){
				
				#print "\npoly2: ", $polyline_of_taxa{$taxon_clade}; 
				&change_color ( \$svg_line, \$href_value_of_substring->{$taxon_clade} ) and next CLADE }
		}
	}
	###############################
	
	###############################
	# Print OUT coloured svg tree
	open  OUT, ">".$$sref_svg_tree || die "\n!FILE-ERROR!: Cannot open ", $$sref_svg_tree, "!\n" ;
	my         $svg_output_tree = join "\n", @svg_lines ;
	print OUT  $svg_output_tree ; close OUT ;
	###############################
	
	sub change_color{
		
		my %colours = ( 
		
		c0	=> '#ccc',
		c1	=> '#00112b',
		c2	=> '#025',
		c3	=> '#003380',    
		c4	=> '#04a',
		c5	=> '#0055d4',
		c6	=> '#06f',
		c7	=> '#2a7fff',
		c8	=> '#59f',
		c9	=> '#80b3ff',
		c10	=> '#acf',
		c11	=> '#FFAAAA',
		c12	=> '#FF8080',
		c13	=> '#FF5555',    
		c14	=> '#FF2A2A',
		c15	=> '#FF0000',
		c16	=> '#D40000',
		c17	=> '#AA0000',
		c18	=> '#800000',
		c19	=> '#550000',
		c20	=> '#2B0000',
		c21	=> 'white'
		
		) ;
		
		my $sref_svg_line		= $_[0] ; #print "\nsvg line: ", $$sref_svg_line ;
		my $sref_split_value	= $_[1] ; #print "\nvalue clade: ", $$sref_split_value;
		
		if		( $$sref_split_value ==  0									) { $$sref_svg_line =~ s/stroke: black/stroke: $colours{c0}/   }
		elsif	( $$sref_split_value  >  0   && $$sref_split_value <=  0.1	) { $$sref_svg_line =~ s/stroke: black/stroke: $colours{c10}/  }
		elsif	( $$sref_split_value  >  0.1 && $$sref_split_value <=  0.2	) { $$sref_svg_line =~ s/stroke: black/stroke: $colours{c9}/   }
		elsif	( $$sref_split_value  >  0.2 && $$sref_split_value <=  0.3	) { $$sref_svg_line =~ s/stroke: black/stroke: $colours{c8}/   }
		elsif	( $$sref_split_value  >  0.3 && $$sref_split_value <=  0.4	) { $$sref_svg_line =~ s/stroke: black/stroke: $colours{c7}/   }
		elsif	( $$sref_split_value  >  0.4 && $$sref_split_value <=  0.5	) { $$sref_svg_line =~ s/stroke: black/stroke: $colours{c6}/   }
		elsif	( $$sref_split_value  >  0.5 && $$sref_split_value <=  0.6	) { $$sref_svg_line =~ s/stroke: black/stroke: $colours{c5}/   }
		elsif	( $$sref_split_value  >  0.6 && $$sref_split_value <=  0.7	) { $$sref_svg_line =~ s/stroke: black/stroke: $colours{c4}/   }
		elsif	( $$sref_split_value  >  0.7 && $$sref_split_value <=  0.8	) { $$sref_svg_line =~ s/stroke: black/stroke: $colours{c3}/   }
		elsif	( $$sref_split_value  >  0.8 && $$sref_split_value <=  0.9	) { $$sref_svg_line =~ s/stroke: black/stroke: $colours{c2}/   }
		elsif	( $$sref_split_value  >  0.9 && $$sref_split_value <=  1	) { $$sref_svg_line =~ s/stroke: black/stroke: $colours{c1}/   }
		
		elsif	( $$sref_split_value  < -0   && $$sref_split_value >= -0.1	) { $$sref_svg_line =~ s/stroke: black/stroke: $colours{c11}/  }
		elsif	( $$sref_split_value  < -0.1 && $$sref_split_value >= -0.2	) { $$sref_svg_line =~ s/stroke: black/stroke: $colours{c12}/  }
		elsif	( $$sref_split_value  < -0.2 && $$sref_split_value >= -0.3	) { $$sref_svg_line =~ s/stroke: black/stroke: $colours{c13}/  }
		elsif	( $$sref_split_value  < -0.3 && $$sref_split_value >= -0.4	) { $$sref_svg_line =~ s/stroke: black/stroke: $colours{c14}/  }
		elsif	( $$sref_split_value  < -0.4 && $$sref_split_value >= -0.5	) { $$sref_svg_line =~ s/stroke: black/stroke: $colours{c15}/  }
		elsif	( $$sref_split_value  < -0.5 && $$sref_split_value >= -0.6	) { $$sref_svg_line =~ s/stroke: black/stroke: $colours{c16}/  }
		elsif	( $$sref_split_value  < -0.6 && $$sref_split_value >= -0.7	) { $$sref_svg_line =~ s/stroke: black/stroke: $colours{c17}/  }
		elsif	( $$sref_split_value  < -0.7 && $$sref_split_value >= -0.8	) { $$sref_svg_line =~ s/stroke: black/stroke: $colours{c18}/  }
		elsif	( $$sref_split_value  < -0.8 && $$sref_split_value >= -0.9	) { $$sref_svg_line =~ s/stroke: black/stroke: $colours{c19}/  }
		elsif	( $$sref_split_value  < -0.9 && $$sref_split_value >= -1	) { $$sref_svg_line =~ s/stroke: black/stroke: $colours{c20}/  }
		
		else	{ $$sref_svg_line =~ s/stroke: black/stroke: $colours{c21}/  }
		
		#print "\nsvg line new: ", $$sref_svg_line, "\n";
	}
}


sub write_matrix_svg {
	
	
	my ( $file , $matrix ) = @_             ;

	my $nrows              = @{$matrix}     ; $nrows--    ; $nrows    *= 10  ; 
	my $ncolumns           = @{$$matrix[0]} ; $ncolumns-- ; $ncolumns *= 10  ;
		
	my $init_line = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>' ;
	my $gen_line  = '<!-- created by matrix_reduction.pl -->'                ;


	my @TAXA ;

	( my $filename = $file )	=~ s/^.*\/// ;
		 $filename				=~ s/.fas$|.fasta$// ;

	( my $filepath = $file	)	=~ s/$filename// ;
		 $filepath				=~ s/.fas$|.fasta$// ;	
		 
	my $file_out 				= $filepath."AliGROOVE_seqsim_matrix_".$filename.".svg";

open my $fh_matrix_out , ">" , $file_out    ;                                   ; 

# + 100 => workaround für viewbox im sichtbaren Bereich (vorher 2)
	my $width = $ncolumns  + 80                                               ;
	my $height= $nrows     + 80                                               ;
	my $rectwidth = $ncolumns  + 2                                            ;
	my $rectheight= $nrows     + 2                                            ;




print $fh_matrix_out <<FRAME;
$init_line
$gen_line

<svg transform="translate(10,70)"
   xmlns:svg="http://www.w3.org/2000/svg"
   xmlns="http://www.w3.org/2000/svg"
   version="1.0"
   width="$width"
   height="$height"
   
   id="svg2">

  <defs
     id="defs4" />

<rect
     width="$rectwidth"
     height="$rectheight"
     x="0"
     y="0"
     style="opacity:1;fill:white;fill-opacity:0;stroke:black;stroke-width:1;stroke-miterlimit:10;stroke-dasharray:none;stroke-opacity:1"
     id="rect001" />


FRAME


my $y = 1 ;

my %colours = ( 
		
		c0  => '#ccc',
		c1  => '#00112b',
		c2  => '#025',
		c3  => '#003380',    
		c4  => '#04a',
		c5  => '#0055d4',
		c6  => '#06f',
		c7  => '#2a7fff',
		c8  => '#59f',
		c9  => '#80b3ff',
		c10 => '#acf',
		c11  => '#FFAAAA',
		c12  => '#FF8080',
		c13  => '#FF5555',    
		c14  => '#FF2A2A',
		c15  => '#FF0000',
		c16  => '#D40000',
		c17  => '#AA0000',
		c18  => '#800000',
		c19  => '#550000',
		c20 => '#2B0000',
		c21 => 'white'
		) ;
     
#c0  => '#ccc', grey          
     
my $genes = shift @$matrix      ;

for my $row ( @$matrix ) {

	my $taxon = shift @$row ;
	
	push @TAXA , $taxon     ;
	
	my $x = 1 ;
	
	for my $rect ( @$row ) {
		
		my $id = int rand 100000 ;
		
		if ( $rect == 0 ) {
			
print $fh_matrix_out <<RECT;

<rect
     width="10"
     height="10"
     x="$x"
     y="$y"
     style="fill:$colours{c0};fill-opacity:1;stroke:black;stroke-width:0.1;stroke-miterlimit:10;stroke-dasharray:none;stroke-opacity:1"
     id="rect$id" />
  
RECT
		
		}
		elsif ( $rect > 0 && $rect <= 0.1 ) {
			
print $fh_matrix_out <<RECT;

<rect
     width="10"
     height="10"
     x="$x"
     y="$y"
     style="fill:$colours{c10};fill-opacity:1;stroke:black;stroke-width:0.1;stroke-miterlimit:10;stroke-dasharray:none;stroke-opacity:1"
     id="rect$id" />
  
RECT
		
		}
		elsif ( $rect > 0.1 && $rect <= 0.2 ) {
			
print $fh_matrix_out <<RECT;

<rect
     width="10"
     height="10"
     x="$x"
     y="$y"
     style="fill:$colours{c9};fill-opacity:1;stroke:black;stroke-width:0.1;stroke-miterlimit:10;stroke-dasharray:none;stroke-opacity:1"
     id="rect$id" />
  
RECT
		
		}
		elsif ( $rect > 0.2 && $rect <= 0.3 ) {
			
print $fh_matrix_out <<RECT;

<rect
     width="10"
     height="10"
     x="$x"
     y="$y"
     style="fill:$colours{c8};fill-opacity:1;stroke:black;stroke-width:0.1;stroke-miterlimit:10;stroke-dasharray:none;stroke-opacity:1"
     id="rect$id" />
  
RECT
		
		}
		elsif ( $rect > 0.3 && $rect <= 0.4 ) {
			
print $fh_matrix_out <<RECT;

<rect
     width="10"
     height="10"
     x="$x"
     y="$y"
     style="fill:$colours{c7};fill-opacity:1;stroke:black;stroke-width:0.1;stroke-miterlimit:10;stroke-dasharray:none;stroke-opacity:1"
     id="rect$id" />
  
RECT
		
		}
		elsif ( $rect > 0.4 && $rect <= 0.5 ) {
			
print $fh_matrix_out <<RECT;

<rect
     width="10"
     height="10"
     x="$x"
     y="$y"
     style="fill:$colours{c6};fill-opacity:1;stroke:black;stroke-width:0.1;stroke-miterlimit:10;stroke-dasharray:none;stroke-opacity:1"
     id="rect$id" />
  
RECT
		
		}
		elsif ( $rect > 0.5 && $rect <= 0.6 ) {
			
print $fh_matrix_out <<RECT;

<rect
     width="10"
     height="10"
     x="$x"
     y="$y"
     style="fill:$colours{c5};fill-opacity:1;stroke:black;stroke-width:0.1;stroke-miterlimit:10;stroke-dasharray:none;stroke-opacity:1"
     id="rect$id" />
  
RECT
		
		}
		elsif ( $rect > 0.6 && $rect <= 0.7 ) {
			
print $fh_matrix_out <<RECT;

<rect
     width="10"
     height="10"
     x="$x"
     y="$y"
     style="fill:$colours{c4};fill-opacity:1;stroke:black;stroke-width:0.1;stroke-miterlimit:10;stroke-dasharray:none;stroke-opacity:1"
     id="rect$id" />
  
RECT
		
		}
		elsif ( $rect > 0.7 && $rect <= 0.8 ) {
			
print $fh_matrix_out <<RECT;

<rect
     width="10"
     height="10"
     x="$x"
     y="$y"
     style="fill:$colours{c3};fill-opacity:1;stroke:black;stroke-width:0.1;stroke-miterlimit:10;stroke-dasharray:none;stroke-opacity:1"
     id="rect$id" />
  
RECT
		
		}
		elsif ( $rect > 0.8 && $rect <= 0.9 ) {
			
print $fh_matrix_out <<RECT;

<rect
     width="10"
     height="10"
     x="$x"
     y="$y"
     style="fill:$colours{c2};fill-opacity:1;stroke:black;stroke-width:0.1;stroke-miterlimit:10;stroke-dasharray:none;stroke-opacity:1"
     id="rect$id" />
  
RECT
		
		}
		elsif ( $rect > 0.9 && $rect <= 1 ) {
			
print $fh_matrix_out <<RECT;

<rect
     width="10"
     height="10"
     x="$x"
     y="$y"
     style="fill:$colours{c1};fill-opacity:1;stroke:black;stroke-width:0.1;stroke-miterlimit:10;stroke-dasharray:none;stroke-opacity:1"
     id="rect$id" />
  
RECT
		
		}
		elsif ( $rect < 0 && $rect >= -0.1 ) {
			
print $fh_matrix_out <<RECT;

<rect
     width="10"
     height="10"
     x="$x"
     y="$y"
     style="fill:$colours{c11};fill-opacity:1;stroke:black;stroke-width:0.1;stroke-miterlimit:10;stroke-dasharray:none;stroke-opacity:1"
     id="rect$id" />
  
RECT
		
		}
		elsif ( $rect < -0.1 && $rect >= -0.2 ) {
			
print $fh_matrix_out <<RECT;

<rect
     width="10"
     height="10"
     x="$x"
     y="$y"
     style="fill:$colours{c12};fill-opacity:1;stroke:black;stroke-width:0.1;stroke-miterlimit:10;stroke-dasharray:none;stroke-opacity:1"
     id="rect$id" />
  
RECT
		
		}
		elsif ( $rect < -0.2 && $rect >= -0.3 ) {
			
print $fh_matrix_out <<RECT;

<rect
     width="10"
     height="10"
     x="$x"
     y="$y"
     style="fill:$colours{c13};fill-opacity:1;stroke:black;stroke-width:0.1;stroke-miterlimit:10;stroke-dasharray:none;stroke-opacity:1"
     id="rect$id" />
  
RECT
		
		}
		elsif ( $rect < -0.3 && $rect >= -0.4 ) {
			
print $fh_matrix_out <<RECT;

<rect
     width="10"
     height="10"
     x="$x"
     y="$y"
     style="fill:$colours{c14};fill-opacity:1;stroke:black;stroke-width:0.1;stroke-miterlimit:10;stroke-dasharray:none;stroke-opacity:1"
     id="rect$id" />
  
RECT
		
		}
		elsif ( $rect < -0.4 && $rect >= -0.5 ) {
			
print $fh_matrix_out <<RECT;

<rect
     width="10"
     height="10"
     x="$x"
     y="$y"
     style="fill:$colours{c15};fill-opacity:1;stroke:black;stroke-width:0.1;stroke-miterlimit:10;stroke-dasharray:none;stroke-opacity:1"
     id="rect$id" />
  
RECT
		
		}
		elsif ( $rect < -0.5 && $rect >= -0.6 ) {
			
print $fh_matrix_out <<RECT;

<rect
     width="10"
     height="10"
     x="$x"
     y="$y"
     style="fill:$colours{c16};fill-opacity:1;stroke:black;stroke-width:0.1;stroke-miterlimit:10;stroke-dasharray:none;stroke-opacity:1"
     id="rect$id" />
  
RECT
		
		}
		elsif ( $rect < -0.6 && $rect >= -0.7 ) {
			
print $fh_matrix_out <<RECT;

<rect
     width="10"
     height="10"
     x="$x"
     y="$y"
     style="fill:$colours{c17};fill-opacity:1;stroke:black;stroke-width:0.1;stroke-miterlimit:10;stroke-dasharray:none;stroke-opacity:1"
     id="rect$id" />
  
RECT
		
		}
		elsif ( $rect < -0.7 && $rect >= -0.8 ) {
			
print $fh_matrix_out <<RECT;

<rect
     width="10"
     height="10"
     x="$x"
     y="$y"
     style="fill:$colours{c18};fill-opacity:1;stroke:black;stroke-width:0.1;stroke-miterlimit:10;stroke-dasharray:none;stroke-opacity:1"
     id="rect$id" />
  
RECT
		
		}
		elsif ( $rect < -0.8 && $rect >= -0.9 ) {
			
print $fh_matrix_out <<RECT;

<rect
     width="10"
     height="10"
     x="$x"
     y="$y"
     style="fill:$colours{c19};fill-opacity:1;stroke:black;stroke-width:0.1;stroke-miterlimit:10;stroke-dasharray:none;stroke-opacity:1"
     id="rect$id" />
  
RECT
		
		}
		elsif ( $rect < -0.9 && $rect >= -1 ) {
			
print $fh_matrix_out <<RECT;

<rect
     width="10"
     height="10"
     x="$x"
     y="$y"
     style="fill:$colours{c20};fill-opacity:1;stroke:black;stroke-width:0.1;stroke-miterlimit:10;stroke-dasharray:none;stroke-opacity:1"
     id="rect$id" />
  
RECT
		
		}
		else {
			
print $fh_matrix_out <<RECT;

<rect
     width="10"
     height="10"
     x="$x"
     y="$y"
     style="fill:$colours{c21};fill-opacity:1;stroke:black;stroke-width:0.1;stroke-miterlimit:10;stroke-dasharray:none;stroke-opacity:0"
     id="rect$id" />
  
RECT
		
		}

	$x += 10
	
	}

	$y += 10
	
}

#save y for taxon labels
my $labelxy = $y+6;





#printing gene names, with shift removes first entry of genes which says just taxa
shift @$genes ;
#set x again for taxon labels, set y again for taxon labels
my $x = 9     ;
$y = 9 ;

for my $gene ( @$genes ) {  
	
	$gene =~ s/_/ /g ;
	$gene =~ s/^\s*//;
	$gene =~ s/\s*$//;

	my $id = int rand 100000 ;

print $fh_matrix_out <<GENES;
<text
     x="$x"
     y="-5"
     transform="rotate(-90,$x,-5)"     	
     style="font-size:8px;font-style:normal;font-weight:normal;fill:black;fill-opacity:1;stroke:none;stroke-width:1px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1;font-family:Bitstream Vera Sans"
     id="text8747"
     xml:space="preserve"><tspan
       x="$x"
       y="-5"
       id="tspan$id">$gene</tspan></text>

<text
     x="$labelxy"
     y="$y"
     style="font-size:8px;font-style:normal;font-weight:normal;fill:black;fill-opacity:1;stroke:none;stroke-width:1px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1;font-family:Bitstream Vera Sans"
     id="text8747"
     xml:space="preserve"><tspan
       x="$labelxy"
       y="$y"
       id="tspan$id">$gene</tspan></text>

GENES

	$x += 10 ;
	$y += 10 ;

}




print $fh_matrix_out <<FINISH;

</svg>

	
FINISH

	
	
}
#############################################################################
###############################################################################################################

=pod

=head1 Copyright

Patrick Kueck, Bernhard Misof, Sandra Meid August 2013

=cut



